﻿using System;
using System.Collections.Generic;

namespace ClassLibrary1
{
    public class Class1
    {
        public List<string> GetNames()
        {
            return new List<string>() { "Tim", "Linda", "Chris", "Matt", "Immo" };
        }
    }
}
